package com.icts.object;

public class ObjFriendChat extends ObjFriend {
	private String txtStatus;
	private String txtTime;

	public String getTxtStatus() {
		return txtStatus;
	}

	public void setTxtStatus(String txtStatus) {
		this.txtStatus = txtStatus;
	}

	public String getTxtTime() {
		return txtTime;
	}

	public void setTxtTime(String txtTime) {
		this.txtTime = txtTime;
	}

}
