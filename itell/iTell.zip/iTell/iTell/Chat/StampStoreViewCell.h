//
//  FriendsViewCell.h
//  iTell
//
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface StampStoreViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *lbTitle;
@property (retain, nonatomic) IBOutlet UILabel *lbSortContent;
@property (retain, nonatomic) IBOutlet UILabel *lbCost;
@property (retain, nonatomic) IBOutlet UIImageView *imgStamp;

@end
