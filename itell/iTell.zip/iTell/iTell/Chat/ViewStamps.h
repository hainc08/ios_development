//
//  ViewStamps.h
//  iTell
//
//  Created by mai van hai on 9/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewStamps : UIView {
    IBOutlet UIScrollView *scrollIcon;
    IBOutlet UIScrollView *scrollStamps;
}

@end
