//
//  CSWebDetailsViewController.h
//  mapLines
//
//  Created by Craig on 5/31/09.
//  Copyright 2009 Craig Spitzkoff. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CSWebDetailsViewController : UIViewController <UIWebViewDelegate>
{
	IBOutlet UIWebView* _webView;
	IBOutlet UIActivityIndicatorView* _activityIndicator;
	
	NSURL* _url;
}

@property(nonatomic, retain) NSURL* url;

-(IBAction) donePressed:(id)sender;

@end
