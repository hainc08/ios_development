//
//  SocketIOJSONSerialization.h
//  v0.22 ARC
//
//  based on
//  socketio-cocoa https://github.com/fpotter/socketio-cocoa
//  by Fred Potter <fpotter@pieceable.com>
//
//  using
//  https://github.com/square/SocketRocket
//  https://github.com/stig/json-framework/
//
//  reusing some parts of
//  /socket.io/socket.io.js
//
//  Created by Philipp Kyeck http://beta-interactive.de
//
//  Updated by
//    samlown   https://github.com/samlown
//    kayleg    https://github.com/kayleg
//

#import <Foundation/Foundation.h>

@interface SocketIOJSONSerialization : NSObject

+ (id) objectFromJSONData:(NSString *)data error:(NSError **)error;
+ (NSString *) JSONStringFromObject:(id)object error:(NSError **)error;

@end
