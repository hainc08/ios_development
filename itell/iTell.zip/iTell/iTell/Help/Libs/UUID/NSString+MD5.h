//
//  NSString+MD5.h
//  yankee
//
//  Created by hoanglm on 2/1/12.
//  Copyright (c) 2012 AI&T. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NSString_MD5) 

- (NSString *)MD5;

@end
