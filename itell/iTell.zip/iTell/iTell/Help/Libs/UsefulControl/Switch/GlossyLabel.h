//
//  background.h
//
//  Created by Ali Nour on 3/11/10.
//  Copyright 2010 BadrIT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GlossyLabel : UILabel {

}

- (id)initWithFrame:(CGRect)frame backgroundColor:(UIColor *)color;

@end
