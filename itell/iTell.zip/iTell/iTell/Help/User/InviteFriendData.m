//
//  InviteFriendData.m
//  iTell
//
//  Created by tranduc on 9/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "InviteFriendData.h"

@implementation InviteFriendData
@synthesize userId, name, email, mobileNum;

@end
