//
//  FriendInfo.h
//  iTell
//
//  Created by Nguyen Lan Huong on 8/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FriendInfo : NSObject{

       
    
    
}
@property (nonatomic, retain)  NSString *avataURL;
@property (nonatomic, retain)  NSString *nickName;
@property (nonatomic, retain)  NSString *statusStr;
@property (nonatomic, retain)  NSString *time;

@end
