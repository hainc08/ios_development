//
//  FriendInfo.m
//  iTell
//
//  Created by Nguyen Lan Huong on 8/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FriendInfo.h"

@implementation FriendInfo

@synthesize avataURL;
@synthesize nickName;
@synthesize statusStr;
@synthesize time;


@end
