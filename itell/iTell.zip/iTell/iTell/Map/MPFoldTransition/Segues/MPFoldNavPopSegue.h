//
//  MPFoldNavPopSegue.h
//  MPFoldTransition (v 1.0.0)
//
//  Created by Mark Pospesel on 4/18/12.
//  Copyright (c) 2012 Mark Pospesel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MPFoldSegue.h"

@interface MPFoldNavPopSegue : MPFoldSegue

- (void)perform;

@end
