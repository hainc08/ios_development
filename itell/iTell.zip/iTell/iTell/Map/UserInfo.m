//
//  UserInfo.m
//  iTell
//
//  Created by Thap on 8/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

@synthesize userId,nickname,status,time,location,imageURL,type,isFemale, distance;


@end
