//
//  ResultNickNameController.h
//  iTell
//
//  Created by admin trator on 8/3/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultNickNameController : UIViewController

- (IBAction)itellBtnClicked:(id)sender;
@end
