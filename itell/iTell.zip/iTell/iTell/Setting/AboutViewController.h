//
//  AboutViewController.h
//  iTell
//
//  Created by mai van hai on 9/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@property (assign, nonatomic) UIViewController *supperController;
- (IBAction)actionBack:(id)sender;

@end
