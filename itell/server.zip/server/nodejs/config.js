
var config = {}

//socket
//config.sk_host = 'localhost';
config.sk_host = '49.212.140.145';
config.sk_port_default = 9001;

//database
config.db_host = 'localhost';
config.db_port = '3306';
config.db_name = 'itell';
config.db_user = 'root';
//config.db_passwd = '';
config.db_passwd = 'kg87btz659';

//redis
config.redis_host = 'localhost';
config.redis_port = '6379';
config.redis_passwd = 'itell@2012!';


module.exports = config;



