<?php
// constants from admin panel
define('ADM_USER_PER_PAGE',20);
define('ADM_COMPANY_PER_PAGE',20);

define('PATH_ITELL', '/itell');
//define('PATH_ITELL', '');

define('ITELL_LINK_URL', 'http://itell.com');
