<?php
/**
 * Description of Stamp
 *
 * @author TuanNguyen
 */
class Stamp extends AppModel {
    //put your code here
}

?>
