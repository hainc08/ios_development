<?php
/**
 * Description of UserContact
 *
 * @author TuanNguyen
 */
class UserContact extends AppModel {
    const APP_NOT_USING = 0;
    const APP_USING_NOT_FRIEND = 1;
    const APP_USING_FRIEND = 2;
}

?>
