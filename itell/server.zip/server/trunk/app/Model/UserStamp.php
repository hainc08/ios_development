<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserStamp
 *
 * @author TuanNguyen
 */
class UserStamp extends AppModel {
    //put your code here
}

?>
